package com.codingworld.service1.flight.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("flight")
public class FlightController {

    Logger logger= LoggerFactory.getLogger(FlightController.class);


    @GetMapping("/home")
    public String FlightController(){
        logger.info("FlightController test");
        return "FlightController service is working";
    }


}
