package com.codingworld.service1.model;

public enum ERole {
  ROLE_USER,
  ROLE_ADMIN
}
