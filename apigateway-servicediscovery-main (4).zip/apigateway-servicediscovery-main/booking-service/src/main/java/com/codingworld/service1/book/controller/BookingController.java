package com.codingworld.service1.book.controller;

import com.codingworld.service1.book.modal.Book;
import com.codingworld.service1.book.service.BookingService;
import com.codingworld.service1.comman.dto.User;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.context.annotation.Lazy;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

import java.util.List;

@RestController
@RequestMapping("/book")
public class BookingController {


    Logger logger= LoggerFactory.getLogger(BookingController.class);

    @Autowired
    private BookingService flightService;


    @Autowired
    private RestTemplate restTemplate;

   // public static final String BOOKING_SERVICE="bookService";



    @GetMapping("/home")
    @CircuitBreaker(name ="book-service",fallbackMethod = "getAllAvailableProducts")
    public String bookingController(@RequestHeader("loggedInUser") String name){
        logger.info("BookingServiceImpl class {} ",name);
        return restTemplate.getForObject("http://FLIGHT-SERVICE/flight/home", String.class);
    }


    @PostMapping("/add")
    public Book add(@RequestBody Book flight,@RequestHeader("loggedInUser") String name) {
        logger.info("FlightController is execute {} and {}",flight,name);
        return flightService.addFlight(flight,name);
    }

    @GetMapping("/{id}")
    public Book getFlightById(@PathVariable Long id) {
        logger.info("FlightController is execute getFlightById",id);
        return flightService.findById(id);
    }


    @GetMapping("/all")
    public List<Book> getAllFlight() {
        logger.info("FlightController is execute getAllFlight");
        return flightService.getAllFlight();
    }

    @DeleteMapping("/delete/{id}")
    public void deleteFlight(@PathVariable Long id) {
        logger.info("FlightController is execute deleteFlight");
        flightService.deleteFlightById(id);
    }

    public String getAllAvailableProducts(Exception e){
        return "This Service is down please contact with administrator";
    }
}
